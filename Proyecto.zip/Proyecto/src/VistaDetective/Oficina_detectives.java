
package VistaDetective;


public class Oficina_detectives {
    
    public static void main(String[] args) {
        
    }
    
}

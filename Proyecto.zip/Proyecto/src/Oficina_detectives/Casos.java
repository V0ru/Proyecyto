package Oficina_detectives;


public class Casos {
    private String Descripcion_caso;
    private String no_caso;
    private String causa_investigacion;
    private String codigo_prioridad_caso;
    private String asignacion_detectivo;
    private String nombre_clave;

    public Casos(String Descripcion_caso, String no_caso, String causa_investigacion, String codigo_prioridad_caso, String asignacion_detectivo, String nombre_clave) {
        this.Descripcion_caso = Descripcion_caso;
        this.no_caso = no_caso;
        this.causa_investigacion = causa_investigacion;
        this.codigo_prioridad_caso = codigo_prioridad_caso;
        this.asignacion_detectivo = asignacion_detectivo;
        this.nombre_clave = nombre_clave;
    }

    public String getDescripcion_caso() {
        return Descripcion_caso;
    }
    public void setDescripcion_caso(String Descripcion_caso) {
        this.Descripcion_caso = Descripcion_caso;
    }
    public String getNo_caso() {
        return no_caso;
    }
    public void setNo_caso(String no_caso) {
        this.no_caso = no_caso;
    }
    public String getCausa_investigacion() {
        return causa_investigacion;
    }
    public void setCausa_investigacion(String causa_investigacion) {
        this.causa_investigacion = causa_investigacion;
    }
    public String getCodigo_prioridad_caso() {
        return codigo_prioridad_caso;
    }
    public void setCodigo_prioridad_caso(String codigo_prioridad_caso) {
        this.codigo_prioridad_caso = codigo_prioridad_caso;
    }
    public String getAsignacion_detectivo() {
        return asignacion_detectivo;
    }
    public void setAsignacion_detectivo(String asignacion_detectivo) {
        this.asignacion_detectivo = asignacion_detectivo;
    }
    public String getNombre_clave() {
        return nombre_clave;
    }
    public void setNombre_clave(String nombre_clave) {
        this.nombre_clave = nombre_clave;
    }

     
    
}

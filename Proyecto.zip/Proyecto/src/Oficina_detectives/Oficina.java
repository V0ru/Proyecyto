package Oficina_detectives;


public class Oficina {
    private String no_identificacion;
    private String nombres;
    private String apellidos;
    private int años_experiencia;
    private String Tipo_caso_capacitado;
    //Datos de los detectives

    public Oficina(String no_identificacion, String nombres, String apellidos, int años_experiencia, String Tipo_caso_capacitado) {
        this.no_identificacion = no_identificacion;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.años_experiencia = años_experiencia;
        this.Tipo_caso_capacitado = Tipo_caso_capacitado;
    }

    public String getNo_identificacion() {
        return no_identificacion;
    }
    public void setNo_identificacion(String no_identificacion) {
        this.no_identificacion = no_identificacion;
    }
    public String getNombres() {
        return nombres;
    }
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }
    public String getApellidos() {
        return apellidos;
    }
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    public int getAños_experiencia() {
        return años_experiencia;
    }
    public void setAños_experiencia(int años_experiencia) {
        this.años_experiencia = años_experiencia;
    }
    public String getTipo_caso_capacitado() {
        return Tipo_caso_capacitado;
    }
    public void setTipo_caso_capacitado(String Tipo_caso_capacitado) {
        this.Tipo_caso_capacitado = Tipo_caso_capacitado;
    }
    
    
    
    
}

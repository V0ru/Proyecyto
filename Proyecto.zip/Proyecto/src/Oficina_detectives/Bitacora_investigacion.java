package Oficina_detectives;

public class Bitacora_investigacion {
    private String fecha_registro;
    private String Observacion;

    public Bitacora_investigacion(String fecha_registro, String Observacion) {
        this.fecha_registro = fecha_registro;
        this.Observacion = Observacion;
    }
    public String getFecha_registro() {
        return fecha_registro;
    }
    public void setFecha_registro(String fecha_registro) {
        this.fecha_registro = fecha_registro;
    }
    public String getObservacion() {
        return Observacion;
    }
    public void setObservacion(String Observacion) {
        this.Observacion = Observacion;
    }
}
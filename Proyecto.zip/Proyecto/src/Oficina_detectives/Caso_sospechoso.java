package Oficina_detectives;

public class Caso_sospechoso {
    private String no_id;
    private String nombre;
    private String alias;
    private String ultima_direccion;
    private String no_vivienda;
    private String localidad;
    private String ciudad;
    private String departamento;
    private String pais;
    private String fotografia;
    private String caracteristicas_fisicas;

    public Caso_sospechoso(String no_id, String nombre, String alias, String ultima_direccion, String no_vivienda, String localidad, String ciudad, String departamento, String pais, String fotografia, String caracteristicas_fisicas) {
        this.no_id = no_id;
        this.nombre = nombre;
        this.alias = alias;
        this.ultima_direccion = ultima_direccion;
        this.no_vivienda = no_vivienda;
        this.localidad = localidad;
        this.ciudad = ciudad;
        this.departamento = departamento;
        this.pais = pais;
        this.fotografia = fotografia;
        this.caracteristicas_fisicas = caracteristicas_fisicas;
    }
    
    public String getNo_id() {
        return no_id;
    }
    public void setNo_id(String no_id) {
        this.no_id = no_id;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getAlias() {
        return alias;
    }
    public void setAlias(String alias) {
        this.alias = alias;
    }
    public String getUltima_direccion() {
        return ultima_direccion;
    }
    public void setUltima_direccion(String ultima_direccion) {
        this.ultima_direccion = ultima_direccion;
    }
    public String getNo_vivienda() {
        return no_vivienda;
    }
    public void setNo_vivienda(String no_vivienda) {
        this.no_vivienda = no_vivienda;
    }
    public String getLocalidad() {
        return localidad;
    }
    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }
    public String getCiudad() {
        return ciudad;
    }
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }
    public String getDepartamento() {
        return departamento;
    }
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }
    public String getPais() {
        return pais;
    }
    public void setPais(String pais) {
        this.pais = pais;
    }
    public String getFotografia() {
        return fotografia;
    }
    public void setFotografia(String fotografia) {
        this.fotografia = fotografia;
    }
    public String getCaracteristicas_fisicas() {
        return caracteristicas_fisicas;
    }
    public void setCaracteristicas_fisicas(String caracteristicas_fisicas) {
        this.caracteristicas_fisicas = caracteristicas_fisicas;
    }
    
    
}


package Oficina_detectives;


public class Tipo_Casos {
    private String Caso_homicidio;
    
    private String Caso_narcotico;
    
    private String Caso_cibercrimen;

    public Tipo_Casos(String Caso_homicidio, String Caso_narcotico, String Caso_cibercrimen) {
        this.Caso_homicidio = Caso_homicidio;
        this.Caso_narcotico = Caso_narcotico;
        this.Caso_cibercrimen = Caso_cibercrimen;
    }

    public String getCaso_homicidio() {
        return Caso_homicidio;
    }

    public void setCaso_homicidio(String Caso_homicidio) {
        this.Caso_homicidio = Caso_homicidio;
    }

    public String getCaso_narcotico() {
        return Caso_narcotico;
    }

    public void setCaso_narcotico(String Caso_narcotico) {
        this.Caso_narcotico = Caso_narcotico;
    }

    public String getCaso_cibercrimen() {
        return Caso_cibercrimen;
    }

    public void setCaso_cibercrimen(String Caso_cibercrimen) {
        this.Caso_cibercrimen = Caso_cibercrimen;
    }   
    public void casoHomicidio(){
        /*se registra adicionalmente un segundo detective, que es el encargado de realizar
        tareas secundarias como interrogatorios, análisis de pruebas, etc.*/
    }
    public void casoNarcotico(){
        //se registra adicionalmente si es un caso local, estatal o federal.
    }
    public void casoCibercrimen(){
        /*se adiciona la línea de cibercrimen asociada (robo de identidad, robo de información, fraudes por internet,
        etc.*/
    }
}



package Vista;

import Modelo.*;
public class CasoCerrado {
    
    public static void main(String[] args) {
        System.out.println("---------------------");
        System.out.println("OFICINA CASO CERRADO ");
        System.out.println("---------------------");
        Casos ca1=new Casos(55555,"crimen por redes sociales","C (relevante)","los pillos");
        ca1.caso();
        System.out.println("-----------------");
        System.out.println("TIPO DE CASO");
        System.out.println("caso 1: cibercrimen ");
        System.out.println("-----------------");
        System.out.println("DECTIVE ASIGNADO");
        System.out.println("-----------------");
        Detectives de1 =new Detectives(1066268141,"leonardo","acuña","5","C");
        System.out.println(de1.toString());
        System.out.println("---------------------");
        System.out.println("SOSPECHOSO DEL CASO");
        System.out.println("---------------------");
        Sospechosos sos1=new Sospechosos(1066268151,19,10,"andres","perez","el chapo","calle 25 #15-87","el socorro","valledupar",
        "cesar","colombia","no tiene","pelo afro,1,80 m de estatura,color moreno,entre 20-25 años de edad");
        System.out.println(sos1.toString());
        System.out.println("-------------------------");
        System.out.println("BITACORA DE INVESTIGACION");
        System.out.println("-------------------------");
        Bitacora bi1=new Bitacora("14/05/2022","el caso fue revisado por un detective, y fue notificado a la oficina de novedades");
        System.out.println(bi1.toString());
    } 
}

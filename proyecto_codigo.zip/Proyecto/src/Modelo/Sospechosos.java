package Modelo;

public class Sospechosos {
    private int id,edad,noVivienda;
    private  String nombre,apellido,alias,direccion,localidad,ciudad,departamento,pais,fotografia,descripcionFisica;
    private Casos casos[];//relacion de agregacion

    public Sospechosos(int id, int edad, int noVivienda, String nombre, String apellido, String alias, String direccion, String localidad, String ciudad, String departamento, String pais, String fotografia, String descripcionFisica) {
        this.id = id;
        this.edad = edad;
        this.noVivienda = noVivienda;
        this.nombre = nombre;
        this.apellido = apellido;
        this.alias = alias;
        this.direccion = direccion;
        this.localidad = localidad;
        this.ciudad = ciudad;
        this.departamento = departamento;
        this.pais = pais;
        this.fotografia = fotografia;
        this.descripcionFisica = descripcionFisica;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getNoVivienda() {
        return noVivienda;
    }

    public void setNoVivienda(int noVivienda) {
        this.noVivienda = noVivienda;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getFotografia() {
        return fotografia;
    }

    public void setFotografia(String fotografia) {
        this.fotografia = fotografia;
    }

    public String getDescripcionFisica() {
        return descripcionFisica;
    }

    public void setDescripcionFisica(String descripcionFisica) {
        this.descripcionFisica = descripcionFisica;
    }
    public Casos[] getCasos() {
        return casos;
    }

    public void setCasos(Casos[] casos) {
        this.casos = casos;
    }
    public Sospechosos() {
    }
    @Override
    public String toString() {
        return "id: " + id + "\nedad:" + edad + "\nnumero de vivienda: " + noVivienda + 
                "\nnombres: " + nombre + "\napellidos: " + apellido + "\nalias: " + alias + 
                "\nultima direccion:" + direccion + "\nlocalidad: " + localidad + "\nciudad: " + ciudad + "\ndepartamento:" + departamento + 
                "\npais: " + pais + "\nfotografia: " + fotografia + "\ndescripcion fisica: " + descripcionFisica;
    }
}

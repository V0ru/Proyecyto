package Modelo;


public class Casos {
    private int numero;
    private String descripcion,codigo,nombreClave;
    private TipoCasos tipoCasos[];//relacion de composicion
    private static final int maxCasos=3;
    private Detectives detectives;//relacion de agregacion
    private Bitacora bitacora;//relacion de composicion
    
    public Casos() {
    }

    public Casos(int numero, String descripcion, String codigo, String nombreClave) {
        this.numero = numero;
        this.descripcion = descripcion;
        this.codigo = codigo;
        this.nombreClave = nombreClave;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombreClave() {
        return nombreClave;
    }

    public void setNombreClave(String nombreClave) {
        this.nombreClave = nombreClave;
    }
    public TipoCasos[] getTipoCasos() {
        return tipoCasos;
    }

    public void setTipoCasos(TipoCasos[] tipoCasos) {
        this.tipoCasos = tipoCasos;
    }

    public Detectives getDetectives() {
        return detectives;
    }

    public void setDetectives(Detectives detectives) {
        this.detectives = detectives;
    }

    public Bitacora getBitacora() {
        return bitacora;
    }

    public void setBitacora(Bitacora bitacora) {
        this.bitacora = bitacora;
    }
    public void caso(){
        System.out.println("numero de caso: "+getNumero()+"\ndescripcion del caso: "+getDescripcion()+"\ncodigo de prioridad: "+getCodigo()
        +"\nnombre en clave: "+getNombreClave());
    }
    
}

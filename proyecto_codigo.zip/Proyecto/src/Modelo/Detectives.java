package Modelo;

public class Detectives {
    private int identificacion;
    private String nombres,apellidos,años;
    private String tipoCaso;

    private Casos casos[];//relacion de agregacion

    public Detectives() {
    }

    public Detectives(int identificacion, String nombres, String apellidos, String años, String tipoCaso) {
        this.identificacion = identificacion;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.años = años;
        this.tipoCaso = tipoCaso;
    }

    public int getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getAños() {
        return años;
    }

    public void setAñosExpe(String añosExpe) {
        this.años = añosExpe;
    }

    public String getTipoCaso() {
        return tipoCaso;
    }

    public void setTipoCaso(String tipoCaso) {
        this.tipoCaso = tipoCaso;
    }
    public Casos[] getCasos() {
        return casos;
    }

    public void setCasos(Casos[] casos) {
        this.casos = casos;
    }
    @Override
    public String toString() {
        return "identificacion: " + identificacion + "\nnombres: " + nombres + 
                "\napellidos: " + apellidos + "\na\u00f1años de experiencia: " + años + 
                "\ntipo de caso: " + tipoCaso  ;
    }
 
}

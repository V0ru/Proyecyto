package Modelo;

public class Bitacora {
    private String fecha;
    private String Observacion;
    private Casos casos ;

    

    public Bitacora(String fecha, String Observacion) {
        this.fecha = fecha;
        this.Observacion = Observacion;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getObservacion() {
        return Observacion;
    }

    public void setObservacion(String Observacion) {
        this.Observacion = Observacion;
    }
    public Casos getCasos() {
        return casos;
    }

    public void setCasos(Casos casos) {
        this.casos = casos;
    }
    public Bitacora() {
    }
    @Override
    public String toString() {
        return "fecha de registro: " + fecha + "\nobservacion: " + Observacion;
    }
}
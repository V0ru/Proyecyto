
package Modelo;


public class TipoCasos {
    private String tipoCaso;
    public TipoCasos() {
    }
    public String getTipoCaso() {
        return tipoCaso;
    }
    public void setTipoCaso(String tipoCaso) {
        this.tipoCaso = tipoCaso;
    }
    public void ciberCrimen(){
      
    }
    public void homicidos(){
        
    }
    public void narcoticos(){
        
    }
}

